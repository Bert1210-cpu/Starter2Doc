<?xml version="1.0"?>

<!-- Generic stylesheet for viewing XML -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xlink="http://www.w3.org/1999/xlink">

	<!-- This template will always be executed, even if this stylesheet is not run on the document root -->
	<xsl:template match="/">
		<html>
		<head>
		</head>
			<xsl:apply-templates/>
		<body>
		</body>
		</html>
	</xsl:template>

<xsl:template match = "Value">
	<xsl:value-of select="@Value"/>
</xsl:template>

<xsl:template match = "Members">
	<xsl:apply-templates select="Symbol"/>
</xsl:template>

<xsl:template match = "ESSymbolDescr">
	<TD width="100pt"><xsl:value-of select="@TypeSpec"/></TD>
</xsl:template>

<xsl:template match = "Symbol">
	<TR><TD max-width="100pt"><font size="4"><xsl:value-of select="@Name"/></font></TD>
		<TD width="150pt"><xsl:apply-templates select="Value"/></TD>
		<xsl:apply-templates select="ESSymbolDescr"/></TR>
	<xsl:apply-templates select="Members"/>
</xsl:template>

<xsl:template match = "Default_Symbols">
	<font face="Arial Black" size="3">Default_Symbols</font><p/>
	<TABLE STYLE="border:1px solid black" border="2">
		<TR><TD max-width="100pt"><font size="4">Symbol</font></TD>
	<TD width="150pt"><font size="4">Actual Value</font></TD>
	<TD width="100pt"><font size="4">Type</font></TD></TR>
		<xsl:apply-templates select="Symbol"/>
	</TABLE><p/>
</xsl:template>

<xsl:template match = "IOs">
	<font face="Arial Black" size="3">IOs</font><p/>
	<TABLE STYLE="border:1px solid black" border="2">
		<TR><TD max-width="100pt"><font size="4">Symbol</font></TD>
	<TD width="150pt"><font size="4">Actual Value</font></TD>
	<TD width="100pt"><font size="4">Type</font></TD></TR>
		<xsl:apply-templates select="Symbol"/>
	</TABLE><p/>
</xsl:template>

<xsl:template match = "Interfaces">
	<font face="Arial Black" size="3">Interfaces</font><p/>
	<TABLE STYLE="border:1px solid black" border="2">
		<TR><TD max-width="100pt"><font size="4">Symbol</font></TD>
	<TD width="150pt"><font size="4">Actual Value</font></TD>
	<TD width="100pt"><font size="4">Type</font></TD></TR>
		<xsl:apply-templates select="Symbol"/>
	</TABLE><p/>
</xsl:template>

<xsl:template match = "ISymbol">
		<xsl:apply-templates/>
</xsl:template>

<xsl:template match = "Configuration">
	Description: <font size="4"><xsl:value-of select="@Description"/></font><p/>
	Configuration: <xsl:value-of select="@Configuration"/><p/>
	<p/>
	<xsl:apply-templates/>
</xsl:template>

<xsl:template match = "IConfig">
	<font face="Arial Black" size="3">Configuration</font><p/>
	<xsl:apply-templates select="Configuration"/>
	<TABLE STYLE="border:1px solid black" border="2">
		<TR><TD max-width="100pt"><font size="4">Symbol</font></TD>
	<TD width="150pt"><font size="4">Actual Value</font></TD>
	<TD width="100pt"><font size="4">Type</font></TD></TR>
		<xsl:apply-templates select="Symbol"/>
	</TABLE><p/>
</xsl:template>

<xsl:template match="IPhysDimUnits"><font face="Arial Black" size="5">IPhysDimUnits:</font><p/>
	<TABLE STYLE="border:1px solid black" border="2">
	<TR>
		<TD width="150pt"><font size="4">PhysDim</font></TD>
		<TD width="50pt"><font size="4">Index</font></TD>
		<TD width="80pt"><font size="4">Unit</font></TD>
		<TD width="50pt"><font size="4">Index</font></TD>
	</TR>
	<xsl:for-each select="PhysDim">
	<TR>
		<TD width="150pt"><xsl:apply-templates select="Name"/></TD>
		<TD width="50pt"><xsl:value-of select="@Index"/></TD>
		<xsl:apply-templates select="Unit"/>
	</TR>
	</xsl:for-each>
	</TABLE><p/>
</xsl:template>

<xsl:template match="Unit">
	<TD width="80pt"><xsl:apply-templates select="Name"/></TD>
	<TD width="50pt"><xsl:value-of select="@Index"/></TD>
</xsl:template>
<xsl:template match="Name">
	<xsl:value-of select="."/>
</xsl:template>

<xsl:template match="ObjMetaData"><font face="Arial Black" size="5">ObjMetaData:</font><p/>
	<TABLE STYLE="border:1px solid black" border="2">
		<xsl:apply-templates select="ActualSnapIn"/>
		<xsl:apply-templates select="Flag"/>
		<xsl:apply-templates select="LogicalAddress"/>
		<xsl:apply-templates select="S7OD"/>
	</TABLE><p/>
	<font face="Arial Black" size="3">Author:</font><p/>
	<xsl:value-of select="Author"/>
	<p/>
	<font face="Arial Black" size="3">Version:</font><p/>
	<xsl:value-of select="Version"/>
	<p/>
	<font face="Arial Black" size="3">Comment:</font><p/>
	<xsl:value-of select="Comment"/>
	<p/>
</xsl:template>

<xsl:template match="ActualSnapIn">
	<TR>
		<TD><font size="4">ActualSnapIn:</font></TD>
	</TR>
	<TR>
		<TD>GUID:</TD>
		<TD><xsl:value-of select="@GUID"/></TD>
	</TR>
</xsl:template>
<xsl:template match="Flag">
	<TR>
		<TD><font size="4">Flag:</font></TD>
		<TD><xsl:value-of select="@Name"/></TD>
	</TR>
	<TR>
		<TD>Flags:</TD>
		<TD><xsl:value-of select="@Flags"/></TD>
	</TR>
</xsl:template>
<xsl:template match="LogicalAddress">
	<TR>
		<TD><font size="4">LogicalAddress:</font></TD>
	</TR>
	<TR>
		<TD>DeviceAddress:</TD>
		<TD><xsl:value-of select="@DeviceAddress"/></TD>
	</TR>
	<TR>
		<TD>TObjectAddress:</TD>
		<TD><xsl:value-of select="@TObjectAddress"/></TD>
	</TR>
</xsl:template>
<xsl:template match="S7OD">
	<TR>
		<TD><font size="4">S7OD:</font></TD>
	</TR>
	<TR>
		<TD>EnvID:</TD>
		<TD><xsl:value-of select="@EnvID"/></TD>
	</TR>
	<TR>
		<TD>UnitID:</TD>
		<TD><xsl:value-of select="@UnitID"/></TD>
	</TR>
	<TR>
		<TD>EnvType:</TD>
		<TD><xsl:value-of select="@EnvType"/></TD>
	</TR>
	<TR>
		<TD>ObjectID:</TD>
		<TD><xsl:value-of select="@ObjectID"/></TD>
	</TR>
	<TR>
		<TD>UnitType:</TD>
		<TD><xsl:value-of select="@UnitType"/></TD>
	</TR>
	<TR>
		<TD>ObjectType:</TD>
		<TD><xsl:value-of select="@ObjectType"/></TD>
	</TR>
</xsl:template>

<xsl:template match="Extension"><font face="Arial Black" size="5">Extension:</font><p/>
	Name:
	<xsl:value-of select="@Name"/><p/>
	TypeID:
	<xsl:value-of select="@TypeID"/><p/>
	TypeName:
	<xsl:value-of select="@TypeName"/><p/>
</xsl:template>

<xsl:template match="IDevNavigate"><font face="Arial Black" size="5">IDevNavigate:</font><p/>
	<xsl:apply-templates select="TPackage"/>
</xsl:template>

<xsl:template match="TPackage">
	<TABLE STYLE="border:1px solid black" border="2">
	<TR>
		<TD><font size="4">TPackage:</font></TD>
		<TD><xsl:value-of select="@TypeName"/></TD>
	</TR>
	<TR>
		<TD>TypeID:</TD>
		<TD><xsl:value-of select="@TypeID"/></TD>
	</TR>
	</TABLE><p/>
</xsl:template>

<xsl:template match="ITaskLevels"><font face="Arial Black" size="5">ITaskLevels:</font><p/>
	<xsl:apply-templates select="BaseTime"/>
	<xsl:apply-templates select="TaskLevel"/>
</xsl:template>

	<xsl:template match="BaseTime">BaseTime:	<xsl:value-of select="@Value"/><p/>
</xsl:template>

<xsl:template match="TaskLevel">
	<TABLE STYLE="border:1px solid black" border="2">
	<TR>
		<TD><font size="4">TaskLevel:</font></TD>
		<TD><font size="4"><xsl:value-of select="@Name"/></font></TD>
	</TR>
	<TR>
		<TD>Type:</TD>
		<TD><xsl:value-of select="@Type"/></TD>
	</TR>
	<xsl:apply-templates select="TaskProps"/>
	<xsl:apply-templates select="RatioFCToRR"/>
	<xsl:apply-templates select="Task"/>
	</TABLE><p/>
</xsl:template>

<xsl:template match="TaskProps">
	<TR>
		<TD>Fix:</TD>
		<TD><xsl:value-of select="@Fix"/></TD>
	</TR>
	<TR>
		<TD>Prio:</TD>
		<TD><xsl:value-of select="@Prio"/></TD>
	</TR>
	<TR>
		<TD>MaxTasks:</TD>
		<TD><xsl:value-of select="@MaxTasks"/></TD>
	</TR>
	<TR>
		<TD>ClockFactor:</TD>
		<TD><xsl:value-of select="@ClockFactor"/></TD>
	</TR>
	<TR>
		<TD>ClockLevelID:</TD>
		<TD><xsl:value-of select="@ClockLevelID"/></TD>
	</TR>
	<TR>
		<TD>TimeOverflow:</TD>
		<TD><xsl:value-of select="@TimeOverflow"/></TD>
	</TR>
	<TR>
		<TD>VisibleFlags:</TD>
		<TD><xsl:value-of select="@VisibleFlags"/></TD>
	</TR>
	<xsl:apply-templates select="desiredCycleTime"/>
</xsl:template>

<xsl:template match="desiredCycleTime">
	<TR>
		<TD>desiredCycleTime:</TD>
		<TD><xsl:value-of select="."/></TD>
	</TR>
</xsl:template>

<xsl:template match="Task">
	<TR>
		<TD><font size="4">Task:</font></TD>
		<TD><font size="4"><xsl:value-of select="@Name"/></font></TD>
	</TR>
	<TR>
		<TD>Priority:</TD>
		<TD><xsl:apply-templates select="Priority"/></TD>
	</TR>
	<TR>
		<TD>CycleTime:</TD>
		<TD><xsl:apply-templates select="CycleTime"/></TD>
	</TR>
	<TR>
		<TD>CycleTimeOffset:</TD>
		<TD><xsl:apply-templates select="CycleTimeOffset"/></TD>
	</TR>
	<TR>
		<TD>TimeLimit:</TD>
		<TD><xsl:apply-templates select="TimeLimit"/></TD>
	</TR>
	<TR>
		<TD>RatioTimeLimit (RatioTime):</TD>
		<TD><xsl:apply-templates select="RatioTimeLimit"/></TD>
	</TR>
	<xsl:apply-templates select="Flags"/>
	<TR>
		<TD>InterruptCondition (Enabled):</TD>
		<TD><xsl:apply-templates select="InterruptCondition"/></TD>
	</TR>
	<TR>
		<TD>TimeCtrlTask (TaskID):</TD>
		<TD><xsl:apply-templates select="TimeCtrlTask"/></TD>
	</TR>
	<xsl:apply-templates select="ProgramList"/>
</xsl:template>

<xsl:template match="Priority">
	<xsl:value-of select="."/>
</xsl:template>

<xsl:template match="CycleTime">
	<xsl:value-of select="."/>
</xsl:template>

<xsl:template match="CycleTimeOffset">
	<xsl:value-of select="."/>
</xsl:template>

<xsl:template match="TimeLimit">
	<xsl:value-of select="."/>
</xsl:template>

<xsl:template match="RatioTimeLimit">
	<xsl:value-of select="@RatioTime"/>
</xsl:template>

<xsl:template match="InterruptCondition">
	<xsl:value-of select="@Enabled"/>
</xsl:template>

<xsl:template match="TimeCtrlTask">
	<xsl:value-of select="@TaskID"/>
</xsl:template>

<xsl:template match="Flags">
	<TR>
		<TD>Fix:</TD>
		<TD><xsl:value-of select="@Fix"/></TD>
	</TR>
	<TR>
		<TD>StartAtRun:</TD>
		<TD><xsl:value-of select="@StartAtRun"/></TD>
	</TR>
	<TR>
		<TD>AWPPossible:</TD>
		<TD><xsl:value-of select="@AWPPossible"/></TD>
	</TR>
	<TR>
		<TD>VisibleFlags:</TD>
		<TD><xsl:value-of select="@VisibleFlags"/></TD>
	</TR>
	<TR>
		<TD>ExecutionFault:</TD>
		<TD><xsl:value-of select="@ExecutionFault"/></TD>
	</TR>
</xsl:template>

<xsl:template match="RatioFCToRR">
	<TR>
		<TD>RatioFCToRR:</TD>
		<TD><xsl:value-of select="@Value"/></TD>
	</TR>
</xsl:template>

<xsl:template match="ProgramList">
	<TR>
		<TD><font size="4">ProgramList:</font></TD>
	</TR>
	<xsl:apply-templates select="Program"/>
</xsl:template>

<xsl:template match="Program">
	<TR>
		<TD>Program:</TD>
		<TD><xsl:value-of select="@Name"/></TD>
	</TR>
	<TR>
		<TD>UnitName:</TD>
		<TD><xsl:value-of select="@UnitName"/></TD>
	</TR>
</xsl:template>

<xsl:template match="ISATopologyNavigate"><xsl:apply-templates/>
</xsl:template>

<xsl:template match="SATopology"><font face="Arial Black" size="5">SATopology</font><p/>
	Type: <xsl:value-of select="@Type"/><p/>
	MasterDeviceID: <xsl:value-of select="@MasterDeviceID"/><p/>
	<xsl:apply-templates select="SAComponents"/>
	<xsl:apply-templates select="SAConnections"/>
</xsl:template>

<xsl:template match="SAComponents">
	<font size="4">SAComponents</font>
	<TABLE STYLE="border:1px solid black" border="2">
	<xsl:for-each select="SAComponentBox">
		<TR>
			<TD><font size="4"><xsl:value-of select="@Name"/></font></TD>
			<TD><font size="4">MLFB:</font></TD>
			<TD colspan="4"><font size="4"><xsl:value-of select="@MLFB"/></font></TD>
		</TR>
		<TR>
			<TD>DeviceID:</TD>
			<TD>Name:</TD>
			<TD>DeviceType:</TD>
			<TD>NodeID.Index:</TD>
			<TD>IsActive:</TD>
			</TR>
		<xsl:for-each select="SAComponent">
			<TR>
				<TD><xsl:value-of select="@DeviceID"/></TD>
				<TD><xsl:value-of select="@Name"/></TD>
				<xsl:apply-templates select="SANodeID"/>
				<TD><xsl:value-of select="@IsActive"/></TD>
			</TR>
		</xsl:for-each>
	</xsl:for-each>
	</TABLE><p/>
</xsl:template>
<xsl:template match="SANodeID">
				<TD><xsl:value-of select="@DeviceType"/></TD>
				<TD><xsl:value-of select="@NodeID.Index"/></TD>
</xsl:template>
<xsl:template match="SAConnections">
	<font size="4">SAConnections</font>
	<TABLE STYLE="border:1px solid black" border="2">
		<TR>
			<TD>SrcDeviceID</TD>
			<TD>SrcPortID</TD>
			<TD>TargetDeviceID</TD>
			<TD>TargetPortID</TD>
		</TR>
	<xsl:for-each select="SAConnection">
		<TR>
			<TD><xsl:value-of select="@SrcDeviceID"/></TD>
			<TD><xsl:value-of select="@SrcPortID"/></TD>
			<TD><xsl:value-of select="@TargetDeviceID"/></TD>
			<TD><xsl:value-of select="@TargetPortID"/></TD>
		</TR>
	</xsl:for-each>
	</TABLE><p/>
</xsl:template>

<xsl:template match = "LocalAlarmData">
	<xsl:for-each select="LocalAlarmReaction">
		<TR><TD>LocalAlarmReaction: </TD>
		<TD>Index: <xsl:value-of select="@Index"/> <p/>
		Value: <xsl:value-of select="@Value"/> </TD></TR>
	</xsl:for-each>
	<xsl:for-each select="LocalAlarmParam">
		<TR><TD>LocalAlarmParam: </TD>
		<TD>Index: <xsl:value-of select="@Index"/> <p/>
		Value: <xsl:value-of select="@Value"/> </TD></TR>
	</xsl:for-each>
</xsl:template>

<xsl:template match = "TOAlarmData">
		<TR><TD><font size="4">ID: </font></TD>
		<TD><font size="4"><xsl:value-of select="@ID"/> </font></TD></TR>
		<TR><TD>Name: </TD>
		<TD><xsl:value-of select="@Name"/> </TD></TR>
		<TR><TD>Type: </TD>
		<TD><xsl:value-of select="@Type"/> </TD></TR>
		<TR><TD>Reaction: </TD>
		<TD><xsl:value-of select="@Reaction"/> </TD></TR>
		<TR><TD>Confirmation: </TD>
		<TD><xsl:value-of select="@Confirmation"/> </TD></TR>
		<TR><TD>DiagnoseBuffer: </TD>
		<TD><xsl:value-of select="@DiagnoseBuffer"/> </TD></TR>
	<xsl:apply-templates select ="LocalAlarmData"/>
</xsl:template>

<xsl:template match = "IAlarmConfig">
	<font face="Arial Black" size="3">IAlarmConfig</font><p/>
	TOName: <font size="4"><xsl:value-of select="@TOName"/></font><p/>
	<p/>
	<TABLE STYLE="border:1px solid black" border="2">
	<xsl:apply-templates select ="TOAlarmData"/>
	</TABLE><p/>
</xsl:template>

<xsl:template match = "Point">
	<TR><TD>Point:</TD>
	<TD>Change:</TD>
	<TD><xsl:value-of select="@Change"/> </TD></TR>
	<TR><TD></TD><TD>DefRange:</TD>
	<TD><xsl:value-of select="@DefRange"/> </TD></TR>
	<TR><TD></TD><TD>ValueRange:</TD>
	<TD><xsl:value-of select="@ValueRange"/> </TD></TR>
</xsl:template>

<xsl:template match = "coefficients">
	<TR><TD>coefficients:</TD>
	<TD>Degree:</TD>
	<TD><xsl:value-of select="@Degree"/> </TD></TR>
	<TR><TD></TD><TD>coeff0:</TD>
	<TD><xsl:value-of select="@coeff0"/> </TD></TR>
	<TR><TD></TD><TD>coeff1:</TD>
	<TD><xsl:value-of select="@coeff1"/> </TD></TR>
	<TR><TD></TD><TD>coeff2:</TD>
	<TD><xsl:value-of select="@coeff2"/> </TD></TR>
	<TR><TD></TD><TD>coeff3:</TD>
	<TD><xsl:value-of select="@coeff3"/> </TD></TR>
	<TR><TD></TD><TD>coeff4:</TD>
	<TD><xsl:value-of select="@coeff4"/> </TD></TR>
	<TR><TD></TD><TD>coeff5:</TD>
	<TD><xsl:value-of select="@coeff5"/> </TD></TR>
	<TR><TD></TD><TD>coeff6:</TD>
	<TD><xsl:value-of select="@coeff6"/> </TD></TR>
</xsl:template>

<xsl:template match = "Sinus">
	<TR><TD>Sinus:</TD>
	<TD>SinB:</TD>
	<TD><xsl:value-of select="@SinB"/> </TD></TR>
	<TR><TD></TD><TD>SinC:</TD>
	<TD><xsl:value-of select="@SinC"/> </TD></TR>
	<TR><TD></TD><TD>SinD:</TD>
	<TD><xsl:value-of select="@SinD"/> </TD></TR>
</xsl:template>

<xsl:template match = "Normalform">
	<TR><TD>Normalform:</TD>
	<TD>End:</TD>
	<TD><xsl:value-of select="@End"/> </TD></TR>
	<TR><TD></TD><TD>Start:</TD>
	<TD><xsl:value-of select="@Start"/> </TD></TR>
</xsl:template>

<xsl:template match = "DefRange">
	<TR><TD>DefRange:</TD>
	<TD>End:</TD>
	<TD><xsl:value-of select="@End"/> </TD></TR>
	<TR><TD></TD><TD>Start:</TD>
	<TD><xsl:value-of select="@Start"/> </TD></TR>
</xsl:template>

<xsl:template match = "ValueRange">
	<TR><TD>ValueRange:</TD>
	<TD>End:</TD>
	<TD><xsl:value-of select="@End"/> </TD></TR>
	<TR><TD></TD><TD>Start:</TD>
	<TD><xsl:value-of select="@Start"/> </TD></TR>
</xsl:template>

<xsl:template match = "linTransformation">
	<TR><TD>linTransformation:</TD></TR>
	<xsl:apply-templates/>
</xsl:template>

<xsl:template match = "Scale">
	<TR><TD></TD><TD>ScaleTo:</TD>
	<TD><xsl:value-of select="@ScaleTo"/> </TD></TR>
	<TR><TD></TD><TD>ScaleFrom:</TD>
	<TD><xsl:value-of select="@ScaleFrom"/> </TD></TR>
	<TR><TD></TD><TD>ScaleFactor:</TD>
	<TD><xsl:value-of select="@ScaleFactor"/> </TD></TR>
</xsl:template>

<xsl:template match = "CAM_Type">
	<TR><TD>CAM_Type:</TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "Start">
	<TR><TD>Start:</TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "End">
	<TR><TD>End:</TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "Starttype">
	<TR><TD>Starttype:</TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "Endtype">
	<TR><TD>Endtype:</TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "Ordercriteria">
	<TR><TD>Ordercriteria:</TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "GeoChanged">
	<TR><TD>GeoChanged:</TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "ScalingChanged">
	<TR><TD>ScalingChanged:</TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "min_Difference_DefRange">
	<TR><TD>min_Difference_DefRange:</TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "max_Difference_DefRange">
	<TR><TD>max_Difference_DefRange:</TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "min_Difference_ValueRange">
	<TR><TD>min_Difference_ValueRange:</TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "max_Difference_ValueRange">
	<TR><TD>max_Difference_ValueRange:</TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "PointTable">
	<TR><TD colspan="2"><font size="4">PointTable:</font></TD></TR>
	<xsl:apply-templates select="Point"/>
</xsl:template>

<xsl:template match = "Polynom">
	<TR><TD><font size="4">Polynom:</font></TD>
	<TD>Change:</TD>
	<TD><xsl:value-of select="@Change"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
	<xsl:apply-templates/>
</xsl:template>

<xsl:template match = "Shift">
	<TR><TD><font size="4">Shift:</font></TD>
	<TD>Axis:</TD>
	<TD><xsl:value-of select="@Axis"/> </TD></TR>
	<TR><TD></TD><TD>Type:</TD>
	<TD><xsl:value-of select="@Type"/> </TD></TR>
	<TR><TD></TD><TD>Shift:</TD>
	<TD><xsl:value-of select="@Shift"/> </TD></TR>
	<xsl:apply-templates/>
</xsl:template>

<xsl:template match = "Scaling">
	<TR><TD><font size="4">Scaling:</font></TD>
	<TD>Axis:</TD>
	<TD><xsl:value-of select="@Axis"/> </TD></TR>
	<TR><TD></TD><TD>Type:</TD>
	<TD><xsl:value-of select="@Type"/> </TD></TR>
	<TR><TD></TD><TD>Index:</TD>
	<TD><xsl:value-of select="@Index"/> </TD></TR>
	<xsl:apply-templates select="Scale"/>
</xsl:template>

<xsl:template match = "Interpolationtype">
	<TR><TD><font size="4">Interpolationtype:</font></TD>
	<TD><xsl:value-of select="."/></TD></TR>
	<TR><TD></TD><TD>VarType:</TD>
	<TD><xsl:value-of select="@VarType"/> </TD></TR>
	<TR><TD></TD><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
</xsl:template>

<xsl:template match = "Correctioninterpolation">
	<TR><TD colspan="2"><font size="4">Correctioninterpolation:</font></TD></TR>
	<TR><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
	<xsl:apply-templates/>
</xsl:template>

<xsl:template match = "Control">
	<TR><TD colspan="2"><font size="4">Control:</font></TD></TR>
	<TR><TD valign="top">Comment:</TD>
	<TD><xsl:value-of select="@Comment"/> </TD></TR>
	<xsl:apply-templates/>
</xsl:template>

<xsl:template match = "CAM_Header_Data">
	<TR><TD colspan="2"><font size="4">CAM_Header_Data:</font></TD></TR>
	<xsl:apply-templates/>
</xsl:template>

<xsl:template match = "CamData">
	<xsl:apply-templates/>
</xsl:template>

<xsl:template match = "ITOCam">
	<font face="Arial Black" size="5">ITOCam	</font><p/>
	<TABLE STYLE="border:1px solid black" border="2">
	<xsl:apply-templates/>
	</TABLE>
</xsl:template>

</xsl:stylesheet>
