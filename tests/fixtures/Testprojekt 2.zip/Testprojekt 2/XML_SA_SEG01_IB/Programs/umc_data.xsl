<?xml version="1.0"?>

<!-- Generic stylesheet for viewing XML -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xlink="http://www.w3.org/1999/xlink">

	<!-- This template will always be executed, even if this stylesheet is not run on the document root -->
	<xsl:template match="/">
		<html>
		<head>
<script language="JavaScript">
function Decode() {

	Data = document.XMLDocument.selectSingleNode("/IExImport/Data").text;

	Lines = Data.split("\n");

	for (i=0; i != Lines.length; i++) {

		Tabs = Lines[i].split("\t");

			for (t=0; t != Tabs.length; t++) {

				document.write(Tabs[t]);
				document.write("&#160;&#160;&#160;&#160;&#160;"); }

			document.write("<br/>");
		}
	}
</script>
		</head>
			<xsl:apply-templates/>
		<body>
		</body>
		</html>
	</xsl:template>

<xsl:template match = "Value">
	<xsl:value-of select="@Value"/>
</xsl:template>

<xsl:template match = "Members">
	<xsl:apply-templates select="Symbol"/>
</xsl:template>

<xsl:template match = "ESSymbolDescr">
	<TD width="100pt"><xsl:value-of select="@TypeSpec"/></TD>
</xsl:template>

<xsl:template match = "Symbol">
	<TR><TD max-width="100pt"><font size="4"><xsl:value-of select="@Name"/></font></TD>
		<TD width="150pt"><xsl:apply-templates select="Value"/></TD>
		<xsl:apply-templates select="ESSymbolDescr"/></TR>
	<xsl:apply-templates select="Members"/>
</xsl:template>

<xsl:template match = "Configuration">
	Description: <font size="4"><xsl:value-of select="@Description"/></font><p/>
	Configuration: <xsl:value-of select="@Configuration"/><p/>
	<p/>
	<xsl:apply-templates/>
</xsl:template>

<xsl:template match = "IConfig">
	<font face="Arial Black" size="3">Configuration</font><p/>
	<xsl:apply-templates select="Configuration"/>
	<TABLE STYLE="border:1px solid black" border="2">
		<TR><TD max-width="100pt"><font size="4">Symbol</font></TD>
	<TD width="150pt"><font size="4">Actual Value</font></TD>
	<TD width="100pt"><font size="4">Type</font></TD></TR>
		<xsl:apply-templates select="Symbol"/>
	</TABLE><p/>
</xsl:template>

<xsl:template match="IExImport">
	<xsl:apply-templates select="Data"/>
</xsl:template>

<xsl:template match="Data">
	<font face="Courier New" size="2">
		<script language="JavaScript">
			Decode();
		</script>
	</font>
	<p/>
</xsl:template>

<xsl:template match="IPhysDimUnits"><font face="Arial Black" size="5">IPhysDimUnits:</font><p/>
	<TABLE STYLE="border:1px solid black" border="2">
	<TR>
		<TD width="150pt"><font size="4">PhysDim</font></TD>
		<TD width="50pt"><font size="4">Index</font></TD>
		<TD width="80pt"><font size="4">Unit</font></TD>
		<TD width="50pt"><font size="4">Index</font></TD>
	</TR>
	<xsl:for-each select="PhysDim">
	<TR>
		<TD width="150pt"><xsl:apply-templates select="Name"/></TD>
		<TD width="50pt"><xsl:value-of select="@Index"/></TD>
		<xsl:apply-templates select="Unit"/>
	</TR>
	</xsl:for-each>
	</TABLE><p/>
</xsl:template>

<xsl:template match="Unit">
	<TD width="80pt"><xsl:apply-templates select="Name"/></TD>
	<TD width="50pt"><xsl:value-of select="@Index"/></TD>
</xsl:template>
<xsl:template match="Name">
	<xsl:value-of select="."/>
</xsl:template>

<xsl:template match="ObjMetaData"><font face="Arial Black" size="5">ObjMetaData:</font><p/>
	<TABLE STYLE="border:1px solid black" border="2">
		<xsl:apply-templates select="ActualSnapIn"/>
		<xsl:apply-templates select="Flag"/>
		<xsl:apply-templates select="LogicalAddress"/>
		<xsl:apply-templates select="S7OD"/>
	</TABLE><p/>
	<font face="Arial Black" size="3">Author:</font><p/>
	<xsl:value-of select="Author"/>
	<p/>
	<font face="Arial Black" size="3">Version:</font><p/>
	<xsl:value-of select="Version"/>
	<p/>
	<font face="Arial Black" size="3">Comment:</font><p/>
	<xsl:value-of select="Comment"/>
	<p/>
</xsl:template>

<xsl:template match="ActualSnapIn">
	<TR>
		<TD><font size="4">ActualSnapIn:</font></TD>
	</TR>
	<TR>
		<TD>GUID:</TD>
		<TD><xsl:value-of select="@GUID"/></TD>
	</TR>
</xsl:template>
<xsl:template match="Flag">
	<TR>
		<TD><font size="4">Flag:</font></TD>
		<TD><xsl:value-of select="@Name"/></TD>
	</TR>
	<TR>
		<TD>Flags:</TD>
		<TD><xsl:value-of select="@Flags"/></TD>
	</TR>
</xsl:template>
<xsl:template match="LogicalAddress">
	<TR>
		<TD><font size="4">LogicalAddress:</font></TD>
	</TR>
	<TR>
		<TD>DeviceAddress:</TD>
		<TD><xsl:value-of select="@DeviceAddress"/></TD>
	</TR>
	<TR>
		<TD>TObjectAddress:</TD>
		<TD><xsl:value-of select="@TObjectAddress"/></TD>
	</TR>
</xsl:template>
<xsl:template match="S7OD">
	<TR>
		<TD><font size="4">S7OD:</font></TD>
	</TR>
	<TR>
		<TD>EnvID:</TD>
		<TD><xsl:value-of select="@EnvID"/></TD>
	</TR>
	<TR>
		<TD>UnitID:</TD>
		<TD><xsl:value-of select="@UnitID"/></TD>
	</TR>
	<TR>
		<TD>EnvType:</TD>
		<TD><xsl:value-of select="@EnvType"/></TD>
	</TR>
	<TR>
		<TD>ObjectID:</TD>
		<TD><xsl:value-of select="@ObjectID"/></TD>
	</TR>
	<TR>
		<TD>UnitType:</TD>
		<TD><xsl:value-of select="@UnitType"/></TD>
	</TR>
	<TR>
		<TD>ObjectType:</TD>
		<TD><xsl:value-of select="@ObjectType"/></TD>
	</TR>
</xsl:template>

<xsl:template match="Extension"><font face="Arial Black" size="5">Extension:</font><p/>
	Name:
	<xsl:value-of select="@Name"/><p/>
	TypeID:
	<xsl:value-of select="@TypeID"/><p/>
	TypeName:
	<xsl:value-of select="@TypeName"/><p/>
</xsl:template>

<xsl:template match="IProgram">
	<xsl:apply-templates select="OptionString"/>
	<xsl:apply-templates select="ExternalCompiler"/>
</xsl:template>

<xsl:template match="OptionString">
	OptionString:
	<xsl:value-of select="."/>
	<p/>
</xsl:template>

<xsl:template match="ExternalCompiler">
	ExternalCompiler: GUID = 
	<xsl:value-of select="@GUID"/>
	<p/>
</xsl:template>

</xsl:stylesheet>
