<?xml version="1.0"?>

<!-- Generic stylesheet for viewing XML -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xlink="http://www.w3.org/1999/xlink">

	<!-- This template will always be executed, even if this stylesheet is not run on the document root -->
	<xsl:template match="/">
		<html>
		<head>
		<script language="JavaScript">
		function checkString(string) {

			tmp1 = string.replace(/%20/g," ");
			tmp2 = tmp1.replace(/%E4/g,"&#228;");
			tmp3 = tmp2.replace(/%F6/g,"&#246;");
			tmp4 = tmp3.replace(/%FC/g,"&#252;");
			tmp5 = tmp4.replace(/%C4/g,"&#196;");
			tmp6 = tmp5.replace(/%D6/g,"&#214;");
			tmp7 = tmp6.replace(/%DC/g,"&#220;");
			tmp8 = tmp7.replace(/%DF/g,"&#223;");

			return tmp8;
		}

		function WriteHref(LinkPath,LinkName)
		{
			document.write(' / <a target="Dir" href="' + LinkPath + '">'+ LinkName + '</a>');
		}

		tmpwindow = window.location.href;
		windowname = tmpwindow.split("/");
		if((parent.length == 0) || (windowname[windowname.length - 1] == "VersionInfo.xml"))
		{
			if(windowname[windowname.length - 1] != "VersionInfo.xml")
				document.write('<title>Export</title>');
			else
				document.write('<title>Version Info</title>');
		}

		else
		{
			rootDirSplit = checkString(parent.location.href).split("/");
			ExportName   = (rootDirSplit[rootDirSplit.length-1]).substring(0,(rootDirSplit[rootDirSplit.length-1]).lastIndexOf('.'));
			NaviSplit    = checkString(window.location.href).split("/");
			LocalName    = (NaviSplit[NaviSplit.length-1]).substring(0,(NaviSplit[NaviSplit.length-1]).lastIndexOf('.'));

			var bDir = 0;
			var iNaviEndOffset = -1;

			if (window.name == "Dir")
			{
				bDir = 1;
				iNaviEndOffset = -2;
				document.write("Navigation bar: ");
			}
			else
				document.write("File: ");

			if (rootDirSplit.length != (NaviSplit.length-1))
			{
				LinkPath = "file://"

				for (i=3; i != (rootDirSplit.length -1); i++) LinkPath += "/" + rootDirSplit[i];
				LinkPath += "/XML_" + ExportName;
				WriteHref(LinkPath + "/XML_" + ExportName + ".xml",ExportName);

				for (i=rootDirSplit.length; i != (NaviSplit.length + iNaviEndOffset); i++)
				{
					LinkPath += "/" + NaviSplit[i];
					WriteHref(LinkPath + "/" + NaviSplit[i] + ".xml",NaviSplit[i]);
				}
				document.write(" / " + LocalName + "<p />");
			}
			else document.write(" / " + ExportName + "<p />");
		}
		</script>

		</head>
			<xsl:apply-templates select="V05_006"/>
		<body>
			<xsl:apply-templates/>
		</body>
		</html>
	</xsl:template>

	<xsl:template match="V05_006">
		<frameset cols="40%,60%">
			<frame src=".\XML_SA_SEG01_IB\XML_SA_SEG01_IB.xml" name="Dir"/>
			<frame name="Data"/>
		</frameset>
	</xsl:template>

	<xsl:template match="TObject">
		<font face="Arial Black" size="4">TObject:</font><p/>
		<font face="Arial Black" size="5"><xsl:value-of select="@Name"/></font><p/>
		TypeID: <xsl:value-of select="@TypeID"/> <p/>
		<xsl:apply-templates/>
	</xsl:template>

	<xsl:template match="SubObject">
		<font face="Arial Black" size="4">SubObject:</font><p/>
		<font face="Arial Black" size="5"><xsl:value-of select="@Name"/></font><p/>
		TypeID: <xsl:value-of select="@TypeID"/> <p/>
		<xsl:apply-templates/>
	</xsl:template>

	<xsl:template match="GenObject">
		<font face="Arial Black" size="4">Generic Object:</font><p/>
		<font face="Arial Black" size="5"><xsl:value-of select="@Name"/></font><p/>
		TypeID: <xsl:value-of select="@TypeID"/> <p/>
		<xsl:apply-templates/>
	</xsl:template>

	<xsl:template match="*[@xlink:href]">
	<xsl:variable name="path">
	 <xsl:value-of select="substring-after(@xlink:href,'\')"/>
	</xsl:variable>
	<xsl:choose>
	<xsl:when test="name()='LinkTable'"/>
	<xsl:when test="name()='ReferenceTable'"/>
	<xsl:when test="name()='S7Station'">
		<a target="Data"><xsl:attribute name="href"><xsl:value-of select="@xlink:href"/></xsl:attribute><xsl:value-of select="@xlink:title"/></a><br/>
	</xsl:when>
	<xsl:when test="contains($path,'\')">
		<a target="Dir"><xsl:attribute name="href"><xsl:value-of select="@xlink:href"/></xsl:attribute><xsl:value-of select="@xlink:title"/></a><br/>
	</xsl:when>
	<xsl:otherwise>
		<a target="Data"><xsl:attribute name="href"><xsl:value-of select="@xlink:href"/></xsl:attribute><xsl:value-of select="@xlink:title"/></a><br/>
	</xsl:otherwise>
	</xsl:choose>
	</xsl:template>

	<xsl:template match="Extension">
	<a target="Data"><xsl:attribute name="href"><xsl:value-of select="@xlink:href"/></xsl:attribute><xsl:value-of select="@xlink:title"/></a><br/>
	</xsl:template>

	<xsl:template match="Device">
		<font face="Arial Black" size="4">Device:</font><p/>
		<font face="Arial Black" size="5"><xsl:value-of select="@Name"/></font><p/>
		TypeID: <xsl:value-of select="@TypeID"/> <p/>
		<xsl:apply-templates/>
	</xsl:template>

	<xsl:template match="DeviceX">
		<font face="Arial Black" size="4">Device:</font><p/>
		<font face="Arial Black" size="5"><xsl:value-of select="@Name"/></font><p/>
		TypeID: <xsl:value-of select="@TypeID"/> <p/>
		<xsl:apply-templates/>
	</xsl:template>

</xsl:stylesheet>
